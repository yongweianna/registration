package com.example.labskill1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

     EditText usernameET;
     EditText passwordET;
     Button loginBT;
     Button registerBT;
     SharedPreferences pref;
     Intent intentMain;
     TextView tx1;
    int counter = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameET = (EditText)findViewById(R.id.usernameET);
        passwordET = (EditText) findViewById(R.id.passwordET);
        loginBT = (Button)findViewById(R.id.loginBT);
        registerBT = (Button) findViewById(R.id.registerBT);
        tx1 = (TextView)findViewById(R.id.textView2);


        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        intentMain = new Intent(LoginActivity.this,MainActivity.class);
        int statuslogout=pref.getInt("logout",1);
        int statusUser=pref.getInt("status",0);
        if(statuslogout==0){
            String username = pref.getString("username","NULL");
            intentMain.putExtra("username" ,username);
            startActivity(intentMain);
        }
        if(statusUser == 1)
        registerBT.setEnabled(true);
       else
            registerBT.setEnabled(false);


        loginBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = pref.getString("username","NULL");
                String password = pref.getString("password","NULL");

                if(usernameET.getText().toString().equals(username) &&
                        passwordET.getText().toString().equals(password)) {
                    Toast.makeText(getApplicationContext(), "Redirecting...",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                    intent.putExtra("username",pref.getString("username","NULL"));
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();
                    tx1.setVisibility(View.VISIBLE);
                    tx1.setBackgroundColor(Color.RED);
                    counter--;
                    tx1.setText(Integer.toString(counter));

                    if (counter == 0) {
                        loginBT.setEnabled(false);

                    }}
            }
        });

        registerBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             Intent intentReg = new Intent(LoginActivity.this,RegisterActivity.class);
            startActivity(intentReg);
            }
        });
    }
}
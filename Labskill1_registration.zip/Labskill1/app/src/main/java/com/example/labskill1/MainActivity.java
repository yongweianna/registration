package com.example.labskill1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");

        pref = getSharedPreferences("user_details",MODE_PRIVATE);

        TextView usernameTV = (TextView) findViewById(R.id.usernameTV);
        usernameTV.setText(username);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logoutMenu:
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("logout", 1); //logout =1 mean already logout
                editor.commit();
                Intent intentLogin = new Intent(MainActivity.this,LoginActivity.class);
                startActivity(intentLogin);
                return true;
            case R.id.settingMenu:
                Intent intentSetting = new Intent(MainActivity.this,SettingActivity.class);
                startActivity(intentSetting);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
}
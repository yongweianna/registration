package com.example.labskill1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
 SharedPreferences pref;
 EditText uname,pwrd;
 Button saveBT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        pref = getSharedPreferences("user_details",MODE_PRIVATE);
        uname = (EditText)findViewById(R.id.txtName);
        pwrd = (EditText)findViewById(R.id.txtPwd);
        saveBT = (Button) findViewById(R.id.saveBT);

        saveBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = uname.getText().toString();
                String password = pwrd.getText().toString();
                if((username != "") && (password !="")) {
                    SharedPreferences.Editor editor = pref.edit();
                    editor.clear();
                    editor.putInt("logout", 0); //logout=1 means already logout
                    editor.putInt("status", 0 ); //status=1 means already have acc
                    editor.putString("username", username);
                    editor.putString("password", password);
                    editor.commit();
                }
                Intent intent = new Intent(RegisterActivity.this,LoginActivity.class);
                startActivity(intent);

            }
        });

    }
}